import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `<h1>Angular SPA with Okta PKCE</h1>`
})
export class AppComponent {}